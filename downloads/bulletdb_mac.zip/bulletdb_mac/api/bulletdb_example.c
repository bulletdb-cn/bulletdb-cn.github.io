#include "bulletdb_c.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

int main()
{
    HBTDBCONN hconn = bulletdb_connect("127.0.0.1", 33060);

    int rc = bulletdb_login(hconn, "test", "test", "");
	if (rc != 0) {
        printf("connect database failed\n");
		goto exit;
	}

	const char* json_result = 0;
	int json_result_size = 0;

    rc = bulletdb_execute_command(hconn, "create database db3", &json_result, &json_result_size);
	if (rc != 0) {
		goto exit;
	}

    rc = bulletdb_execute_command(hconn, "use db3", &json_result, &json_result_size);
	if (rc != 0) {
		goto exit;
	}
    rc = bulletdb_execute_sql(hconn, "CREATE TABLE IF NOT EXISTS accounts(account_no INTEGER PRIMARY KEY, balance DECIMAL, name CHAR(16));",
		&json_result, &json_result_size);
	if (rc != 0) {
		goto exit;
	}
    rc = bulletdb_execute_sql(hconn, "REPLACE INTO accounts (account_no,balance,name) VALUES (100, 10000.699, 'john');",
		&json_result, &json_result_size);
	if (rc != 0) {
		goto exit;
	}

    rc = bulletdb_execute_sql(hconn, "REPLACE INTO accounts (account_no,balance,name) VALUES (200, 88.666666, 'harry');",
		&json_result, &json_result_size);
	if (rc != 0) {
		goto exit;
	}
    rc = bulletdb_execute_sql(hconn, "SELECT * from accounts",
		&json_result, &json_result_size);
	if (rc != 0) {
		goto exit;
	}

	
    /**  fetch records in json string **/
    const char* json_col_info = 0;
    int json_info_size = 0;
    rc = bulletdb_get_json_columns_info(hconn, &json_col_info, &json_info_size);
    if (rc == 0) {
        printf("%s\n", json_col_info);
    }
	else {
		goto exit;
	}

    const char* json_records = 0;
    int json_record_size = 0;

    while ((rc = bulletdb_fetch_json_records(hconn, &json_records, &json_record_size)) > 0) {
        printf("%s\n", json_records);
    }

    rc = bulletdb_execute_sql(hconn, "SELECT * from accounts", &json_result, &json_result_size);
	if (rc != 0) {
		goto exit;
	}


    /** fetch records, organized by column**/
    column_info* cols_info = 0;
    int cols_num = 0;
    int i,j;

    rc = bulletdb_get_columns_info(hconn, &cols_info, &cols_num);
	if (rc == 0) {
		for (i = 0; i < cols_num; ++i) {
			if (i != 0) printf(",");
			printf("%s", cols_info[i].name);
		}
		printf("\n");
	}
	else {
		goto exit;
	}
    column_data* cols_data = 0;
    int cols_data_num = 0;
    while ((rc = bulletdb_fetch_records(hconn, &cols_data, &cols_data_num)) > 0) {

        int *col_cur_pos = (int*)malloc(cols_num*sizeof(int));
		for (i = 0; i < cols_num; ++i)
			col_cur_pos[i] = 0;

        for(i = 0; i < rc; ++i) {
            for (j = 0; j < cols_num; ++j) {
                if (j != 0) {
                    printf(",");
                }
                switch (cols_info[j].type) {
                    case BTDB_INTEGER: {
                        int num = 0;
                        memcpy(&num, cols_data[j].data + col_cur_pos[j], 4);
                        col_cur_pos[j] += 4;
                        printf("%d", num);
                        break;
                    }
                    case BTDB_BIG_INT: {
                        long long num = 0;
                        memcpy(&num, cols_data[j].data + col_cur_pos[j], 8);
                        col_cur_pos[j] += 8;
                        printf("%lld", num);
                        break;
                    }
                    case BTDB_FLOAT: {
                        double num = 0;
                        memcpy(&num, cols_data[j].data + col_cur_pos[j], 4);
                        col_cur_pos[j] += 4;
                        printf("%f", num);
                        break;
                    }
                    case BTDB_REAL: {
                        double num = 0;
                        memcpy(&num, cols_data[j].data + col_cur_pos[j], 8);
                        col_cur_pos[j] += 8;
                        printf("%f", num);
                        break;
                    }
                    case BTDB_TEXT:
                    case BTDB_BLOB: {
						
                        int bytes = 0;
                        memcpy(&bytes, cols_data[j].data + col_cur_pos[j], 4);
                        col_cur_pos[j] += 4;
						//TODO: text ending zero
                        printf("%s", cols_data[j].data + col_cur_pos[j]);
                        col_cur_pos[j] += bytes;

                        break;
                    }
                    case BTDB_NUMBER: {
                        
                        char txt[30] = {0};
                        int ret = bulletdb_number_to_str(cols_data[j].data + col_cur_pos[j], txt, sizeof(txt));
                        printf("%s", txt);

						//assert(sizeof(btdb_number) == 12);
						//printf("sizeof(btdb_number):%d", sizeof(btdb_number));
						col_cur_pos[j] += 12;

                        break;
                    }
                    default:
                        printf("unknown column type:%d\n", cols_info[i].type);
                }
            }
            printf("\n");
        }
        free(col_cur_pos);
    }

exit:
	if (rc != 0) {
		printf("error:%d, %s\n", rc, bulletdb_error_message(hconn));
	}
    bulletdb_close(hconn);

    return 0;
}