#ifndef _BULLETDB_C_H_
#define _BULLETDB_C_H_

#if defined(_MSC_VER)
#define BTDB_EXPORT   __declspec(dllexport)
#else
#define BTDB_EXPORT __attribute__((visibility("default")))
#endif

#define BTDB_UNKNOWN    0
#define BTDB_INTEGER    1	
#define BTDB_BIG_INT    2
#define BTDB_FLOAT      8
#define BTDB_REAL       9
#define BTDB_NUMBER     14
#define BTDB_TEXT       18
#define BTDB_BLOB       19
#define BTDB_NULL       26

#if defined(__cplusplus)
extern "C"
{
#endif

#if (defined(__SVR4) && defined(__sun))
#pragma pack(1)
#else
#pragma pack(push,1)
#endif
	typedef struct column_info
	{
		const char* name;
		int type;
	} column_info;

	typedef struct column_data
	{
		const char* data;
		int size;
	} column_data;

#if (defined(__SVR4) && defined(__sun))
#pragma pack(0)
#else
#pragma pack(pop)
#endif

	typedef unsigned long long HBTDBCONN;

	BTDB_EXPORT HBTDBCONN bulletdb_connect(const char* host, int port);

	BTDB_EXPORT int bulletdb_login(HBTDBCONN hconn, const char* user, const char* passwd, const char* database);

	BTDB_EXPORT int bulletdb_execute_command(HBTDBCONN hconn, const char* command, const char** json_result, int* json_size);

	BTDB_EXPORT int bulletdb_execute_sql(HBTDBCONN hconn, const char* sql, const char** json_result, int* json_size);

	BTDB_EXPORT const char* bulletdb_error_message(HBTDBCONN hconn);

	BTDB_EXPORT int bulletdb_get_columns_info(HBTDBCONN hconn, const column_info** column_info_ptr, int* column_num);

	BTDB_EXPORT int bulletdb_fetch_records(HBTDBCONN hconn, const column_data** column_data_ptr, int* column_num);

	BTDB_EXPORT int bulletdb_get_json_columns_info(HBTDBCONN hconn, const char** json_result, int* json_size);

	BTDB_EXPORT int bulletdb_fetch_json_records(HBTDBCONN hconn, const char** json_result, int* json_size);

	BTDB_EXPORT void bulletdb_close(HBTDBCONN hconn);

	BTDB_EXPORT int bulletdb_number_to_str(const char* number, char* out_buff, int buff_size);

#if defined(__cplusplus)
}
#endif

#endif