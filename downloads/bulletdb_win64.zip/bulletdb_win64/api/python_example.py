import bulletdb

def main_fun():
    conn = bulletdb.bulletdb()

    conn.connect(host="127.0.0.1", port=33060, user="", passwd="")

    ret = conn.execute_command("show databases;")
    ret = conn.execute_command("use db1;")
    ret = conn.execute_command("show tables;")
    ret = conn.execute_sql("select * from stock_history;")

    while True:
        ret = conn.fetch_json_records()

        if ret["ret_code"] != 0 or ret["records_num"] == 0:
            break

    ret = conn.execute_sql("select * from stock_history;")

    while True:
        ret = conn.fetch_records()
        if ret["ret_code"] != 0 or ret["records_num"] == 0:
            break

        for i in ret["columns"]:
            print(i.hex())


if __name__ == "__main__":

    main_fun()

    pass