import ctypes
import json
import platform
import os

def load_bulletdb_dll():

	cdll_names = {
		'Darwin' : 'libbulletdb_sdk.dylib',
		'Linux'  : 'libbulletdb_sdk.so',
		'Windows': 'bulletdb_sdk.dll'}

	path_file = os.path.dirname(__file__) + "/" + cdll_names[platform.system()]

	return ctypes.cdll.LoadLibrary(path_file)


class bulletdb_except(Exception):
	def __init__(self, code, msg):
		self.code = code
		self.msg = msg

	def __str__(self):
		return "error: " + str(self.code) + ", " + self.msg


class column_data(ctypes.Structure):
	_pack_ = 1
	_fields_=[("data", ctypes.c_void_p), ("size", ctypes.c_uint32)]

class bulletdb:
	def __init__(self):
		self._conn = 0

		self._dll = load_bulletdb_dll()

		self._dll.bulletdb_connect.restype = ctypes.c_ulonglong
		self._dll.bulletdb_error_message.restype = ctypes.c_char_p

	def __exit__(self, type, value, trace):
		if self._conn != 0:
			self._dll.bulletdb_close(self._conn)

	def connect(self, host="127.0.0.1", port=33060, user="", passwd="", database = ""):

		self._conn = self._dll.bulletdb_connect(host.encode('utf8'), port)

		rc = self._dll.bulletdb_login(ctypes.c_ulonglong(self._conn), user.encode('utf8'), passwd.encode('utf8'), database.encode('utf8'))

		if rc != 0:
			msg = self._dll.bulletdb_error_message(ctypes.c_ulonglong(self._conn))
			raise bulletdb_except(rc, msg.decode('utf8'))


	def close(self):
		if self._conn != 0:
			self._dll.bulletdb_close(ctypes.c_ulonglong(self._conn))
			self._conn = None

	def execute_command(self, cmd):

		json_data = ctypes.c_char_p(0)
		json_len = ctypes.c_int(0)

		rc = self._dll.bulletdb_execute_command(ctypes.c_ulonglong(self._conn), cmd.encode('utf8'), ctypes.pointer(json_data), ctypes.pointer(json_len))

		if rc != 0:
			msg = self._dll.bulletdb_error_message(ctypes.c_ulonglong(self._conn))
			raise bulletdb_except(rc, msg.decode('utf8'))
		else:
			return {"ret_code":rc, "json_data":json_data.value.decode('utf8'), "msg":""}


	def execute_sql(self, sql):
		json_data = ctypes.c_char_p(0)
		json_len = ctypes.c_int(0)

		rc = self._dll.bulletdb_execute_sql(ctypes.c_ulonglong(self._conn), sql.encode('utf8'), ctypes.pointer(json_data), ctypes.pointer(json_len))

		if (rc != 0):
			msg = self._dll.bulletdb_error_message(ctypes.c_ulonglong(self._conn))
			return {"ret_code": rc, "json_data": "", "msg": msg.decode('utf8')}
		else:
			return {"ret_code":rc, "json_data":json_data.value.decode('utf8'), "msg":""}


	def get_columns_info(self):

		json_data = ctypes.c_char_p(0)
		json_len = ctypes.c_int(0)

		rc = self._dll.bulletdb_get_json_columns_info(ctypes.c_ulonglong(self._conn), ctypes.pointer(json_data), ctypes.pointer(json_len))

		if rc != 0:
			msg = self._dll.bulletdb_error_message(ctypes.c_ulonglong(self._conn))
			raise bulletdb_except(rc, msg.decode('utf8'))
		else:
			return {"ret_code":rc, "json_data":json_data.value.decode('utf8'), "msg":""}


	def fetch_json_records(self):

		json_data = ctypes.c_char_p(0)
		json_len = ctypes.c_int(0)
		rc = self._dll.bulletdb_fetch_json_records(ctypes.c_ulonglong(self._conn), ctypes.pointer(json_data), ctypes.pointer(json_len))

		if rc < 0:
			msg = self._dll.bulletdb_error_message(ctypes.c_ulonglong(self._conn))
			raise bulletdb_except(-rc, msg.decode('utf8'))
		else:
			records_data = ""
			if rc > 0:
				records_data = json_data.value.decode('utf8')
			return {"ret_code":0, "records_num":rc, "json_data": records_data, "msg":""}


	def fetch_records(self):
		records_data = ctypes.c_void_p(0)
		column_num = ctypes.c_int(0)
		rc = self._dll.bulletdb_fetch_records(ctypes.c_ulonglong(self._conn), ctypes.pointer(records_data),
												ctypes.pointer(column_num))

		if rc < 0:
			msg = self._dll.bulletdb_error_message(ctypes.c_ulonglong(self._conn))
			raise bulletdb_except(rc, msg.decode('utf8'))
		else:
			col_list = []

			records_data = ctypes.cast(records_data, ctypes.POINTER(column_data))
			# print(records_data[0])

			for i in range(column_num.value):
				#ctypes.
				col_data = ctypes.string_at(records_data[i].data, records_data[i].size)
				col_list.append(col_data)

			return {"ret_code": 0, "records_num": rc, "columns": col_list, "msg": ""}